package Model;


public interface Pagable {
    void realizarPago(double monto);
    double getDeuda();
}