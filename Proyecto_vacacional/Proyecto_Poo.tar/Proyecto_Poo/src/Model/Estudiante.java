package Model;


public class Estudiante extends Persona implements Pagable {
    private int edad;
    private String genero;
    private double deuda;

    public Estudiante(int id, String nombre, String apellido, int edad, String genero, double deuda) {
        super(id, nombre, apellido);
        this.edad = edad;
        this.genero = genero;
        this.deuda = deuda;
    }


    public Estudiante(int id, String nombre, String apellido, int edad, String genero) {
        this(id, nombre, apellido, edad, genero, 0.0);
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    @Override
    public void realizarPago(double monto) {
        if (monto > 0 && this.deuda >= monto) {
            this.deuda -= monto;
            System.out.println("Pago de $" + monto + " realizado. Nueva deuda: $" + this.deuda);
        } else if (monto > 0 && this.deuda < monto) {
            System.out.println("El pago de $" + monto + " excede la deuda de $" + this.deuda + ". Se pagó el total de la deuda.");
            this.deuda = 0.0;
        } else {
            System.out.println("Monto de pago inválido.");
        }
    }

    @Override
    public double getDeuda() {
        return deuda;
    }

    public void setDeuda(double deuda) {
        this.deuda = deuda;
    }



    @Override
    public String toString() {
        return "ID: " + id + ", Nombre: " + nombre + ", Apellido: " + apellido +
               ", Edad: " + edad + ", Género: " + genero + ", Deuda: $" + String.format("%.2f", deuda);
    }

    @Override
    public String getInformacionCompleta() {
        return "Estudiante - ID: " + id + ", Nombre: " + nombre + " " + apellido +
               ", Edad: " + edad + ", Género: " + genero + ", Deuda: $" + String.format("%.2f", deuda);
    }


}
