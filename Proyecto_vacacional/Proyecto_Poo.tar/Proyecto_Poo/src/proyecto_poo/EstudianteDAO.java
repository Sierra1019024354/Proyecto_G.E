package proyecto_poo;

import Model.Estudiante;
import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


public class EstudianteDAO {
    private List<Estudiante> estudiantes; 
    private static final String NOMBRE_ARCHIVO = "estudiantes.txt";

    public EstudianteDAO() {
        this.estudiantes = new ArrayList<>();
        cargarEstudiantesDesdeArchivo();
    }

    public void agregarEstudiante(Estudiante estudiante) {
        estudiantes.add(estudiante);
        guardarEstudiantesEnArchivo(); 
        System.out.println("Estudiante agregado: " + estudiante.getNombre());
    }

    public Estudiante obtenerEstudiantePorId(int id) {
        for (Estudiante est : estudiantes) {
            if (est.getId() == id) {
                return est;
            }
        }
        return null;
    }

    public List<Estudiante> obtenerTodosLosEstudiantes() {
        return new ArrayList<>(estudiantes); 
    }

    public boolean actualizarEstudiantes(Estudiante estudianteActualizado) {
        for (int i = 0; i < estudiantes.size(); i++) {
            if (estudiantes.get(i).getId() == estudianteActualizado.getId()) {
                estudiantes.set(i, estudianteActualizado);
                guardarEstudiantesEnArchivo(); 
                System.out.println("Estudiante actualizado: " + estudianteActualizado.getNombre());
                return true;
            }
        }
        return false;
    }

    public boolean eliminarEstudiantes(int id) {
        Iterator<Estudiante> iterator = estudiantes.iterator();
        while (iterator.hasNext()) {
            Estudiante est = iterator.next();
            if (est.getId() == id) {
                iterator.remove();
                guardarEstudiantesEnArchivo(); 
                System.out.println("Estudiante eliminado con ID: " + id);
                return true;
            }
        }
        return false;
    }

    public boolean realizarPago(int idEstudiante, double montoPago) {
        Estudiante estudiante = obtenerEstudiantePorId(idEstudiante);
        if (estudiante != null) {
            estudiante.realizarPago(montoPago); 
            guardarEstudiantesEnArchivo(); 
            return true;
        }
        System.out.println("Estudiante con ID " + idEstudiante + " no encontrado para realizar pago.");
        return false;
    }


    private void guardarEstudiantesEnArchivo() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(NOMBRE_ARCHIVO))) {
            for (Estudiante est : estudiantes) {
                writer.println(est.getId() + "," + est.getNombre() + "," + est.getApellido() + "," +
                               est.getEdad() + "," + est.getGenero() + "," + est.getDeuda());
            }
        } catch (IOException e) {
            System.err.println("Error al guardar estudiantes en archivo: " + e.getMessage());
        }
    }

    private void cargarEstudiantesDesdeArchivo() {
        estudiantes.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(NOMBRE_ARCHIVO))) {
            String linea;
            while ((linea = reader.readLine()) != null) {
                String[] partes = linea.split(",");
                if (partes.length == 6) {
                    try {
                        int id = Integer.parseInt(partes[0]);
                        String nombre = partes[1];
                        String apellido = partes[2];
                        int edad = Integer.parseInt(partes[3]);
                        String genero = partes[4];
                        double deuda = Double.parseDouble(partes[5]);
                        estudiantes.add(new Estudiante(id, nombre, apellido, edad, genero, deuda));
                    } catch (NumberFormatException e) {
                        System.err.println("Error de formato en línea de archivo: " + linea);
                    }
                }
            }
        } catch (FileNotFoundException e) {
            System.out.println("El archivo " + NOMBRE_ARCHIVO + " no existe. Se creará uno nuevo al guardar.");
        } catch (IOException e) {
            System.err.println("Error al cargar estudiantes desde archivo: " + e.getMessage());
        }
    }
}
