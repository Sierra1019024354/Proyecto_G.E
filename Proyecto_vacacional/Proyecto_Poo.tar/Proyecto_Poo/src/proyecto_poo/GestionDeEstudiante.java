package proyecto_poo;

import Model.Estudiante;
import javax.swing.JOptionPane;
import java.util.List;
import javax.swing.table.DefaultTableModel;

public class GestionDeEstudiante extends javax.swing.JFrame {
    private EstudianteDAO estudianteDAO;
    private DefaultTableModel modeloTabla;

    public GestionDeEstudiante() {
        initComponents();
        estudianteDAO = new EstudianteDAO();
        inicializarTabla();
        cargarEstudiantesEnTabla();
    }

    private void inicializarTabla() {
        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("ID");
        modeloTabla.addColumn("Nombre");
        modeloTabla.addColumn("Apellido");
        modeloTabla.addColumn("Edad");
        modeloTabla.addColumn("Género");
        modeloTabla.addColumn("Deuda");
        estudiantesTable.setModel(modeloTabla);
    }
 private void cargarEstudiantesEnTabla() {
        modeloTabla.setRowCount(0);
        List<Estudiante> estudiantes = estudianteDAO.obtenerTodosLosEstudiantes(); //
        for (Estudiante est : estudiantes) {
            modeloTabla.addRow(new Object[]{
                est.getId(),
                est.getNombre(),
                est.getApellido(),
                est.getEdad(),
                est.getGenero(),
                String.format("%.2f", est.getDeuda())
            });
        }
    }

    private void limpiarCampos() {
        idField.setText("");
        nombreField.setText("");
        apellidoField.setText("");
        edadField.setText("");
        generoComboBox.setSelectedIndex(0); // "GENERO"
        pagarField.setText("");
    }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        generoComboBox = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        nombreField = new javax.swing.JTextField();
        apellidoField = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        agregarButton = new javax.swing.JButton();
        eliminarButton = new javax.swing.JButton();
        actualizarButton = new javax.swing.JButton();
        pagarButton = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        estudiantesTable = new javax.swing.JTable();
        idField = new javax.swing.JTextField();
        edadField = new javax.swing.JTextField();
        pagarField = new javax.swing.JTextField();
        mostrarTodosButton = new javax.swing.JButton();
        AñadirDeuda = new javax.swing.JLabel();
        deudaAddCampo = new javax.swing.JTextField();
        añadirDeudaButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("GESTION DE ESTUDIANTES");
        setBackground(new java.awt.Color(51, 255, 0));

        jLabel1.setFont(new java.awt.Font("Algerian", 2, 14)); // NOI18N
        jLabel1.setText("ID");

        jLabel2.setFont(new java.awt.Font("Algerian", 2, 14)); // NOI18N
        jLabel2.setText("Nombre");

        jLabel3.setFont(new java.awt.Font("Algerian", 2, 14)); // NOI18N
        jLabel3.setText("Apellido");

        generoComboBox.setBackground(new java.awt.Color(0, 0, 0));
        generoComboBox.setForeground(new java.awt.Color(255, 255, 255));
        generoComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "GENERO", "HOMBRE", "MUJER" }));
        generoComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                generoComboBoxActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Algerian", 2, 14)); // NOI18N
        jLabel4.setText("Edad");

        nombreField.setBackground(new java.awt.Color(0, 0, 0));
        nombreField.setForeground(new java.awt.Color(255, 255, 255));

        apellidoField.setBackground(new java.awt.Color(0, 0, 0));
        apellidoField.setForeground(new java.awt.Color(255, 255, 255));

        jLabel5.setFont(new java.awt.Font("Algerian", 2, 14)); // NOI18N
        jLabel5.setText("Genero");

        agregarButton.setBackground(new java.awt.Color(0, 51, 255));
        agregarButton.setFont(new java.awt.Font("Algerian", 2, 14)); // NOI18N
        agregarButton.setForeground(new java.awt.Color(255, 255, 255));
        agregarButton.setText("agregar");
        agregarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                agregarButtonActionPerformed(evt);
            }
        });

        eliminarButton.setBackground(new java.awt.Color(255, 51, 51));
        eliminarButton.setFont(new java.awt.Font("Algerian", 2, 14)); // NOI18N
        eliminarButton.setForeground(new java.awt.Color(255, 255, 255));
        eliminarButton.setText("eliminar ");
        eliminarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eliminarButtonActionPerformed(evt);
            }
        });

        actualizarButton.setBackground(new java.awt.Color(153, 255, 0));
        actualizarButton.setFont(new java.awt.Font("Algerian", 2, 14)); // NOI18N
        actualizarButton.setForeground(new java.awt.Color(255, 255, 255));
        actualizarButton.setText("actualizar");
        actualizarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                actualizarButtonActionPerformed(evt);
            }
        });

        pagarButton.setBackground(new java.awt.Color(255, 255, 0));
        pagarButton.setFont(new java.awt.Font("Algerian", 2, 14)); // NOI18N
        pagarButton.setForeground(new java.awt.Color(255, 255, 255));
        pagarButton.setText("pagar");
        pagarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pagarButtonActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Algerian", 2, 14)); // NOI18N
        jLabel6.setText("Pagar");

        estudiantesTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "", "", "", "", "", ""
            }
        ));
        jScrollPane1.setViewportView(estudiantesTable);

        idField.setBackground(new java.awt.Color(0, 0, 0));
        idField.setForeground(new java.awt.Color(255, 255, 255));

        edadField.setBackground(new java.awt.Color(0, 0, 0));
        edadField.setForeground(new java.awt.Color(255, 255, 255));

        pagarField.setBackground(new java.awt.Color(0, 0, 0));
        pagarField.setForeground(new java.awt.Color(255, 255, 255));
        pagarField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                pagarFieldActionPerformed(evt);
            }
        });

        mostrarTodosButton.setBackground(new java.awt.Color(0, 0, 0));
        mostrarTodosButton.setFont(new java.awt.Font("Algerian", 2, 14)); // NOI18N
        mostrarTodosButton.setForeground(new java.awt.Color(255, 255, 255));
        mostrarTodosButton.setText("Mostrar Todo");
        mostrarTodosButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mostrarTodosButtonActionPerformed(evt);
            }
        });

        AñadirDeuda.setFont(new java.awt.Font("Algerian", 2, 14)); // NOI18N
        AñadirDeuda.setText("Añadir Deuda");

        deudaAddCampo.setBackground(new java.awt.Color(0, 0, 0));
        deudaAddCampo.setForeground(new java.awt.Color(255, 255, 255));

        añadirDeudaButton.setFont(new java.awt.Font("Algerian", 2, 14)); // NOI18N
        añadirDeudaButton.setText("Añadir Deuda");
        añadirDeudaButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                añadirDeudaButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(45, 45, 45)
                .addComponent(idField, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(62, 62, 62)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(edadField, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(pagarField, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(nombreField, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(62, 62, 62)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(generoComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(70, 70, 70)
                .addComponent(AñadirDeuda, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(deudaAddCampo, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 71, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(apellidoField, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addComponent(agregarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44)
                .addComponent(eliminarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(actualizarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addComponent(añadirDeudaButton, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44)
                .addComponent(pagarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(mostrarTodosButton, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 806, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(idField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(edadField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pagarField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel4)
                            .addComponent(jLabel6))))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(nombreField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(generoComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(deudaAddCampo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel5)
                            .addComponent(AñadirDeuda))))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(jLabel3))
                    .addComponent(apellidoField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(53, 53, 53)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(agregarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(eliminarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(actualizarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(mostrarTodosButton, javax.swing.GroupLayout.PREFERRED_SIZE, 41, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(añadirDeudaButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(pagarButton, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(35, 35, 35)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void agregarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_agregarButtonActionPerformed
 try {
            int id = Integer.parseInt(idField.getText()); 
            String nombre = nombreField.getText(); 
            String apellido = apellidoField.getText(); 
            int edad = Integer.parseInt(edadField.getText()); 
            String genero = generoComboBox.getSelectedItem().toString(); 

            if (nombre.isEmpty() || apellido.isEmpty() || genero.equals("GENERO")) {
                JOptionPane.showMessageDialog(this, "Por favor complete todos los campos (Nombre, Apellido, Edad, Género).", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            if (estudianteDAO.obtenerEstudiantePorId(id) != null) { 
                JOptionPane.showMessageDialog(this, "Ya existe un estudiante con el ID: " + id, "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Estudiante nuevoEstudiante = new Estudiante(id, nombre, apellido, edad, genero); //
            estudianteDAO.agregarEstudiante(nuevoEstudiante); 
            cargarEstudiantesEnTabla(); 
            limpiarCampos(); //
            JOptionPane.showMessageDialog(this, "Estudiante agregado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Por favor ingrese valores válidos para ID y Edad.", "Error de formato", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_agregarButtonActionPerformed

    private void generoComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_generoComboBoxActionPerformed
        
    }//GEN-LAST:event_generoComboBoxActionPerformed

    private void eliminarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eliminarButtonActionPerformed
           try {
            int id = Integer.parseInt(idField.getText()); //
            if (estudianteDAO.eliminarEstudiantes(id)) { //
                cargarEstudiantesEnTabla(); //
                limpiarCampos(); //
                JOptionPane.showMessageDialog(this, "Estudiante eliminado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "No se encontró un estudiante con el ID proporcionado.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Por favor ingrese un ID válido para eliminar.", "Error de formato", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_eliminarButtonActionPerformed

    private void actualizarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_actualizarButtonActionPerformed
               try {
            int id = Integer.parseInt(idField.getText()); //
            String nombre = nombreField.getText(); //
            String apellido = apellidoField.getText(); //
            int edad = Integer.parseInt(edadField.getText()); //
            String genero = generoComboBox.getSelectedItem().toString(); //

            if (nombre.isEmpty() || apellido.isEmpty() || genero.equals("GENERO")) {
                JOptionPane.showMessageDialog(this, "Por favor complete todos los campos (Nombre, Apellido, Edad, Género) para actualizar.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            Estudiante estudianteActualizado = new Estudiante(id, nombre, apellido, edad, genero, estudianteDAO.obtenerEstudiantePorId(id).getDeuda()); //
            if (estudianteDAO.actualizarEstudiantes(estudianteActualizado)) { //
                cargarEstudiantesEnTabla(); //
                limpiarCampos(); //
                JOptionPane.showMessageDialog(this, "Estudiante actualizado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(this, "No se encontró un estudiante con el ID para actualizar.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Por favor ingrese valores válidos para ID y Edad.", "Error de formato", JOptionPane.ERROR_MESSAGE);
        } catch (NullPointerException ex) {
            JOptionPane.showMessageDialog(this, "El estudiante con el ID especificado no existe para actualizar.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_actualizarButtonActionPerformed

    private void pagarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pagarButtonActionPerformed
       try {
            int id = Integer.parseInt(idField.getText()); //
            double montoPago = Double.parseDouble(pagarField.getText()); //

            if (montoPago <= 0) {
                JOptionPane.showMessageDialog(this, "El monto a pagar debe ser mayor que cero.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            Estudiante estudiante = estudianteDAO.obtenerEstudiantePorId(id); //
            if (estudiante != null) {
                double deudaActual = estudiante.getDeuda(); //
                if (deudaActual == 0) {
                    JOptionPane.showMessageDialog(this, "El estudiante con ID " + id + " no tiene deuda pendiente.", "Información", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
                
                if (montoPago > deudaActual) {
                    int confirm = JOptionPane.showConfirmDialog(this, 
                            "El monto de pago ($" + String.format("%.2f", montoPago) + ") excede la deuda actual ($" + String.format("%.2f", deudaActual) + "). ¿Desea pagar la deuda total?",
                            "Confirmar Pago", JOptionPane.YES_NO_OPTION);
                    if (confirm == JOptionPane.NO_OPTION) {
                        return;
                    }
                }
                
                if (estudianteDAO.realizarPago(id, montoPago)) { //
                    cargarEstudiantesEnTabla(); //
                    limpiarCampos(); //
                    JOptionPane.showMessageDialog(this, "Pago realizado exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "Error al realizar el pago.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Estudiante con ID " + id + " no encontrado para realizar pago.", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Por favor ingrese valores válidos para ID y Monto a Pagar.", "Error de formato", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_pagarButtonActionPerformed

    private void mostrarTodosButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mostrarTodosButtonActionPerformed
      cargarEstudiantesEnTabla(); //
        limpiarCampos(); //
    }//GEN-LAST:event_mostrarTodosButtonActionPerformed

    private void añadirDeudaButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_añadirDeudaButtonActionPerformed
          try {
            int id = Integer.parseInt(idField.getText()); // Obtener el ID del estudiante
            double montoAAgregar = Double.parseDouble(deudaAddCampo.getText()); // Obtener el monto a añadir

            if (montoAAgregar <= 0) {
                JOptionPane.showMessageDialog(this, "El monto a añadir debe ser mayor que cero.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Estudiante estudiante = estudianteDAO.obtenerEstudiantePorId(id); // Buscar el estudiante
            if (estudiante != null) {
                double deudaActual = estudiante.getDeuda();
                estudiante.setDeuda(deudaActual + montoAAgregar); // Sumar el monto a la deuda actual

                if (estudianteDAO.actualizarEstudiantes(estudiante)) { // Actualizar en el DAO
                    cargarEstudiantesEnTabla(); // Refrescar la tabla
                    limpiarCampos(); // Limpiar los campos de entrada
                    JOptionPane.showMessageDialog(this, "Deuda de $" + String.format("%.2f", montoAAgregar) + " añadida exitosamente.", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "Error al añadir la deuda. No se pudo actualizar el estudiante.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(this, "Estudiante con ID " + id + " no encontrado para añadir deuda.", "Error", JOptionPane.ERROR_MESSAGE);
            }

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Por favor ingrese valores numéricos válidos para ID y Monto a Añadir.", "Error de formato", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_añadirDeudaButtonActionPerformed

    private void pagarFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_pagarFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_pagarFieldActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GestionDeEstudiante.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GestionDeEstudiante.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GestionDeEstudiante.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GestionDeEstudiante.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GestionDeEstudiante().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel AñadirDeuda;
    private javax.swing.JButton actualizarButton;
    private javax.swing.JButton agregarButton;
    private javax.swing.JTextField apellidoField;
    private javax.swing.JButton añadirDeudaButton;
    private javax.swing.JTextField deudaAddCampo;
    private javax.swing.JTextField edadField;
    private javax.swing.JButton eliminarButton;
    private javax.swing.JTable estudiantesTable;
    private javax.swing.JComboBox<String> generoComboBox;
    private javax.swing.JTextField idField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton mostrarTodosButton;
    private javax.swing.JTextField nombreField;
    private javax.swing.JButton pagarButton;
    private javax.swing.JTextField pagarField;
    // End of variables declaration//GEN-END:variables

}
